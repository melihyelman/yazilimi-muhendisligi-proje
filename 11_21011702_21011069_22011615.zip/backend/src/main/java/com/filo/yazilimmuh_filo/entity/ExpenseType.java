package com.filo.yazilimmuh_filo.entity;

public enum ExpenseType {
    MAINTENANCE,
    INSURANCE,
    FUEL,
    REPAIR,
    TIRE
}