package com.filo.yazilimmuh_filo.entity;

public enum UserRole {
    ADMIN,
    VENDOR,
    EMPLOYEE
}
