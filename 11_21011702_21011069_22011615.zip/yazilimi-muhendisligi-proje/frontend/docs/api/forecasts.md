Assigments
BASE_URL = /api/forecast


GET - BASE_URL?period = return Map<ExpenseType, Double>