package com.filo.yazilimmuh_filo.entity;

public enum OwnershipType {
    OWNED,
    LEASED
}
