package com.filo.yazilimmuh_filo.repository;

import com.filo.yazilimmuh_filo.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}
