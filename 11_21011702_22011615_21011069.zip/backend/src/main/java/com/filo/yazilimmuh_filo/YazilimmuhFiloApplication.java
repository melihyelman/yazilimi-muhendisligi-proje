package com.filo.yazilimmuh_filo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YazilimmuhFiloApplication {

	public static void main(String[] args) {
		SpringApplication.run(YazilimmuhFiloApplication.class, args);
	}

}
