package com.filo.yazilimmuh_filo.repository;

import com.filo.yazilimmuh_filo.entity.PoolAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PoolAssignmentRepository extends JpaRepository<PoolAssignment, Long> {
}
