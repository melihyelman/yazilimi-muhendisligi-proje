package com.filo.yazilimmuh_filo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YazilimmuhFiloApplicationTests {

	@Test
	void contextLoads() {
	}

}
